package org.telegram.tgnet;

import org.telegram.messenger.UserConfig;

/**
 * Offlinegram: local emulation of the Telegram server.
 * Requests are answered in-process; nothing leaves the device.
 *
 * handle() returns true if the request was answered locally.
 */
public class OfflineServer {

    public static final boolean ENABLED = true;
    private static final int OFFLINE_DC = 2;

    public interface Reply {
        void done(TLObject response, TLRPC.TL_error error);
    }

    public static boolean handle(int account, TLObject req, Reply reply) {
        if (!ENABLED) {
            return false;
        }
        if (req instanceof TLRPC.TL_auth_sendCode) {
            TLRPC.TL_auth_sentCode r = new TLRPC.TL_auth_sentCode();
            r.type = new TLRPC.TL_auth_sentCodeTypeSms();
            ((TLRPC.TL_auth_sentCodeTypeSms) r.type).length = 5;
            r.phone_code_hash = "offline_" + System.currentTimeMillis();
            reply.done(r, null);
            return true;
        }
        if (req instanceof TLRPC.TL_auth_signIn) {
            // any code is accepted; no existing account -> ask for sign up
            reply.done(null, error(400, "PHONE_NUMBER_UNOCCUPIED"));
            return true;
        }
        if (req instanceof TLRPC.TL_auth_signUp) {
            TLRPC.TL_auth_signUp s = (TLRPC.TL_auth_signUp) req;
            TLRPC.TL_auth_authorization a = new TLRPC.TL_auth_authorization();
            TLRPC.TL_user u = new TLRPC.TL_user();
            u.id = 777000L + (Math.abs(s.phone_number.hashCode()) % 1000000);
            u.self = true;
            u.first_name = s.first_name;
            u.last_name = s.last_name;
            u.phone = s.phone_number;
            u.flags |= 1 | 2 | 4 | 8;
            a.user = u;
            reply.done(a, null);
            return true;
        }
        return false;
    }

    private static TLRPC.TL_error error(int code, String text) {
        TLRPC.TL_error e = new TLRPC.TL_error();
        e.code = code;
        e.text = text;
        return e;
    }
}
