# Offlinegram — этап 1 (патч)

Накладывается поверх вашего Telegram-master (копировать с заменой).

Сделано:
- OfflineServer.java: локальный «сервер». Отвечает на auth.sendCode (любой номер), auth.signIn (любой код), auth.signUp (создаёт аккаунт локально).
- ConnectionsManager.java: все запросы идут в OfflineServer, сеть не используется; статус всегда «Connected». Неизвестные запросы возвращают ошибку OFFLINE_NOT_IMPLEMENTED.

НЕ сделано (следующие этапы):
- хранение аккаунта и сообщений (messages.getDialogs/getHistory/sendMessage, updates.getState, help.getConfig, users.getUsers и др.)
- ребрендинг (имя, иконка, applicationId), свои api_id/api_hash
- проверка сборки: код НЕ компилировался, SDK/NDK у меня нет
